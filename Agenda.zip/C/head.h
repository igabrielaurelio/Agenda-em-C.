#ifndef head_h
#define head_h

int menu();
void criarcontato();
void apagacontato();
void editarnome();
void editaremail();
void editartelefone();
void acessarcontato();
int tipodeedicao();
#endif
